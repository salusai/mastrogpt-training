def postgen(args):
  return { "output": "postgen"}
